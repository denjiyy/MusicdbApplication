package bg.musicapp.musicdb.model.entities.enums;

public enum Genre {
  POP, ROCK, JAZZ, METAL, CLASSIC, CHALGICHKA
}
