package bg.musicapp.musicdb.service;

public interface CarouselService {

  String firstImage();
  String secondImage();
  String thirdImage();

}
