package bg.musicapp.musicdb.model.entities.enums;

public enum UserRole {
  ADMIN,
  USER
}
