package bg.musicapp.musicdb.service;

import java.util.List;

public interface ImageShuffler {

  void shuffle(List<String> images);
}
